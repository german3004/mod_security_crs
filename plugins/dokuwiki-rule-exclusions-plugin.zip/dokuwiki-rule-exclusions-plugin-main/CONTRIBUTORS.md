# Contributors to DokuWiki Rule Exclusions Plugin

- [Christian Folini](https://github.com/dune73)
- [Ervin Hegedus](https://github.com/airween)
- [Walter Hop](https://github.com/lifeforms)
- [Andrew Howe](https://github.com/RedXanadu)
- [Max Leske](https://github.com/theseion)
- [Chaim Sanders](https://github.com/csanders-git)
- [Federico G. Schwindt](https://github.com/fgsch)
- [Simon Studer](https://github.com/studersi)
- [Felipe Zipitría](https://github.com/fzipi)
