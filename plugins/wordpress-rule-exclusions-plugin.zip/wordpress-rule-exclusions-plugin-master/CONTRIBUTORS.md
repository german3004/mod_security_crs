# Contributors to WordPress Rule Exclusions Plugin

- [agusmu](https://github.com/agusmu)
- [Christian Folini](https://github.com/dune73)
- [Ervin Hegedus](https://github.com/airween)
- [Walter Hop](https://github.com/lifeforms)
- [Max Leske](https://github.com/theseion)
- [Jose Nazario](https://github.com/paralax)
- [Chaim Sanders](https://github.com/csanders-git)
- [Federico G. Schwindt](https://github.com/fgsch)
- [siric](https://github.com/siric)
- [Jozef Sudolský](https://github.com/azurit)
- [Felipe Zipitría](https://github.com/fzipi)
