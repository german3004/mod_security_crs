# Contributors to cPanel Rule Exclusions Plugin

- [Christoph Hansen](https://github.com/emphazer)
- [Ervin Hegedus](https://github.com/airween)
- [Walter Hop](https://github.com/lifeforms)
- [Andrew Howe](https://github.com/RedXanadu)
- [Max Leske](https://github.com/theseion)
- [Felipe Zipitría](https://github.com/fzipi)
