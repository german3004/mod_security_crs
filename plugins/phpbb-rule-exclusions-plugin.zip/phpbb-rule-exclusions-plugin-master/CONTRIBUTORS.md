# Contributors to phpBB Rule Exclusions Plugin

- [Ervin Hegedus](https://github.com/airween)
- [Walter Hop](https://github.com/lifeforms)
- [Max Leske](https://github.com/theseion)
- [Jozef Sudolský](https://github.com/azurit)
- [Felipe Zipitría](https://github.com/fzipi)
