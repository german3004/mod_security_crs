# Contributors to Antivirus Plugin

- [Max Leske](https://github.com/theseion)
- [Jozef Sudolský](https://github.com/azurit)
