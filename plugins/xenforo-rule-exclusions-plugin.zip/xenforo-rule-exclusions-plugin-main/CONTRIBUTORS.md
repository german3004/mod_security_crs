# Contributors to XenForo Rule Exclusions Plugin

- [Ervin Hegedus](https://github.com/airween)
- [Walter Hop](https://github.com/lifeforms)
- [Andrew Howe](https://github.com/RedXanadu)
- [Max Leske](https://github.com/theseion)
- [Federico G. Schwindt](https://github.com/fgsch)
- [ThanhPT](https://github.com/nevol1708)
- [Felipe Zipitría](https://github.com/fzipi)
