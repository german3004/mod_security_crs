# Contributors to Fake Bot Plugin

- [Christian Folini](https://github.com/dune73)
- [Max Leske](https://github.com/theseion)
- [Jozef Sudolský](https://github.com/azurit)
