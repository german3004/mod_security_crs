# Contributors to Google OAuth2 Plugin

- [Max Leske](https://github.com/theseion)
- [Jozef Sudolský](https://github.com/azurit)
